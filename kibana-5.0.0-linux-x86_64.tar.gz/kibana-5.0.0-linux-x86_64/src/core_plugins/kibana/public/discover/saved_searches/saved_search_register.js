export default function savedSearchObjectFn(savedSearches) {
  return savedSearches;
};

export default function savedDashboardFn(savedDashboards) {
  return savedDashboards;
};

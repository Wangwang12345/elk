import 'plugins/kibana/doc/controllers/doc';

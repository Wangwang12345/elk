require 'jar_dependencies'
require_jar('org.apache.logging.log4j', 'log4j-1.2-api', '2.6.2')
require_jar('org.apache.logging.log4j', 'log4j-api', '2.6.2')
require_jar('org.apache.logging.log4j', 'log4j-core', '2.6.2')
require_jar('com.fasterxml.jackson.core', 'jackson-core', '2.7.4')
require_jar('com.fasterxml.jackson.core', 'jackson-databind', '2.7.4')
require_jar('org.logstash', 'logstash-core', '5.0.0')

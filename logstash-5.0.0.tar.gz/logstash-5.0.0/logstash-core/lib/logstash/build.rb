# encoding: utf-8
BUILD_INFO = {"build_date"=>"2016-10-26T04:09:44Z", "build_sha"=>"6ffe6451db6a0157cc6dd23458a0342c3118a9b0", "build_snapshot"=>false}